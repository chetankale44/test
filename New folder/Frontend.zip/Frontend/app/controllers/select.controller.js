(function (app) {
	app.controller('SelectController', SelectController);

	SelectController.$inject = ['$scope', 'engagements', '$state', '$stateParams', 'USER'];

	function SelectController($scope, engagements, $state, $stateParams, USER) {

		//Scope Variables
		$scope.engagements = engagements;
		$scope.engagement = $scope.engagements[0];
		$scope.release = {};
		$scope.user = USER;

		//Scope Functions
		$scope.createRelease = createRelease;
		$scope.viewDashboard = viewDashboard;

		activate();

		function activate() {
			$scope.release = $scope.engagements[0].releases[0];
		}

		function viewDashboard() {
			$state.go('releaseDashboard', {
				releaseId: $scope.releaseId
			});
		}

		function createRelease() {
			$state.go('createMilestones', {
				erlist: $scope.engagements
			});
		}
	}
})(angular.module('ROD'));
