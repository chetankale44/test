(function (app) {
	app.controller('IndexController', IndexController);

	IndexController.$inject = ['$scope', '$state', 'releaseService', 'userService', 'USER'];

	function IndexController($scope, $state, releaseService, userService, USER) {

		//Scope Variables
		$scope.$state = $state;
		$scope.user = USER;

		//Scope Functions
		$scope.editRelease = editRelease;
		$scope.editCategories = editCategories;
		$scope.appAdmin = appAdmin;
		$scope.updateStatus = updateStatus;
		$scope.viewDashboard = viewDashboard;
		$scope.logout = logout;

		function viewDashboard() {
			$state.go('releaseDashboard', {
				releaseId: releaseService.viewRelease.id
			});
		}

		function updateStatus() {
			$state.go('updateStatus', {
				release: releaseService.viewRelease
			});
		}

		function appAdmin() {
			$state.go('appAdmin', {
				release: releaseService.viewRelease
			});
		}

		function editRelease() {
			$state.go('editRelease', {
				release: releaseService.viewRelease
			});
		}

		function editCategories() {
			$state.go('editCategories', {
				release: releaseService.viewRelease
			});
		}

		function logout() {
			userService.logout().then(function (response) {
				console.log(response);
				window.location = "https://www.e-access.att.com/empsvcs/hrpinmgt/pagLogout/";
			});
		}
	}
})(angular.module('ROD'));
