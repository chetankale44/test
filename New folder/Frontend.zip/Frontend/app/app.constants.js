(function (app) {
	app.constant('API', (function () {
		return {
			'RELEASE_SAVE': 'http://localhost:8080/RMD/services/releases/save',
			'RELEASE_GET': '../data/release-5002.json',
			'USER_ADMIN': '../data/user.json',
			'USER_SIGNOUT': '/ROD/services/users/signout',
			'ENGAGEMENT_LIST': '../data/erList.json',
			'ENGAGEMENT_ADMIN': {
				'PREFIX': '../data/erList.json',
				'SUFFIX': ''
			},
			'APPLICATION_UPDATE': '/ROD/services/applications/issues/add',
			'APPLICATION_DELETE': '/ROD/services/applications/delete',
			'MILESTONE_UPDATE': '/ROD/services/milestones/update',
			'CATEGORIES_DELETE': '/ROD/services/categories/delete'

		}
	})()).constant('FILES', (function () {
		return {
			'HOME': '../app/views/select.html',
			'DELETE': '../app/views/modals/modal-delete.html',
			'RESET': '../app/views/modals/modal-reset.html'
		}
	})()).constant('CONSTANTS', (function () {
		return {
			'TIME_FORMAT_Z': 'ddd hh:mm A MM/DD/YY Z',
			'TIME_FORMAT': 'ddd hh:mm A MM/DD/YY',
			'TZ_OFFSET': ' -0600', //space in beginning is important
			'TZ': 'America/Chicago',
			'AT_RISK_DEADLINE': 15,
			'STATUS_NOT_COMPLETE': '#FFFFFF',
			'STATUS_COMPLETE': '#00B050',
			'STATUS_AT_RISK': '#FFFF00',
			'STATUS_MISSED_DEADLINE': '#C00000',
			'STATUS_NOT_APPLICABLE': '#767171',
			'REFRESH_INTERVAL': 180000,
			'MAX_PRIMARY_MILESTONES': 8,
			'MIN_PRIMARY_MILESTONES': 5,
			'REGEX': {
				'NAME': /^[\w\d@&,\-_\\\(\)\s\/]+$/,
				'ADMIN': /^[a-zA-Z]{2}[a-zA-Z0-9]{4}\s*(?:,\s*[a-zA-Z]{2}[a-zA-Z0-9]{4})*$/
			}
		}
	})());
})(angular.module('ROD'));
