(function (app) {
	app.service('userService', ['$http', 'API', userService]);

	function userService($http, API) {
		var service = {
			getEngagementsByUser: getEngagementsByUser,
			logout: logout
		};

		return service;

		function getEngagementsByUser(attid) {
			//../data/user.json
			//http://localhost:8080/RMD/services/users/admin/rx228x
			return $http.get(API.USER_ADMIN).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}

		function logout() {
			return $http.get(API.USER_SIGNOUT).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}
	}
})(angular.module('ROD'));
