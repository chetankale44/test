(function (app) {
	app.service('indexService', ['$http', 'API', indexService]);

	function indexService($http, API) {
		var service = {
			getAllEngagements: getAllEngagements,
			getReleaseAdmins: getReleaseAdmins
		};

		return service;

		function getAllEngagements() {
			//../data/erList.json
			//http://localhost:8080/RMD/services/engagements/erList
			return $http.get(API.ENGAGEMENT_LIST).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}

		function getReleaseAdmins(engagementId) {
			return $http.get(API.ENGAGEMENT_ADMIN.PREFIX + API.ENGAGEMENT_ADMIN.SUFFIX).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}
	}
})(angular.module('ROD'));
