(function (app) {
	app.value('USER', (function () {
		/*console.log(document.cookie.split(';'));
var cookies = document.cookie.split(';');
var obj = {};
for (let cookie of cookies) {
	var pair = cookie.split('=');
	obj[pair[0].trim()] = pair[1].trim();
}
var attid = "";
var temp = decodeURIComponent(obj["attESHr"]).split('|');
var check = temp[2].split('@');
if (check[1] === 'us.att.com') {
	attid = check[0];
} else {
	attid = temp[7].split(',')[0];
}*/
		var attid = "rx228y";
		console.log(attid);
		return {
			ATTID: attid,
			isReleaseAdmin: {
				value: true,
				ofEngagement: 2,
				ofSelectedEngagement: false
			},
			isAppAdmin: {
				value: false,
				ofApplications: null
			},
			isDeploymentManager: {
				value: false,
				ofApplications: null,
				ofMilestones: null
			}
		}
	})());
})(angular.module('ROD'));
