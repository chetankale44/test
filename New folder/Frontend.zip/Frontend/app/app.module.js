angular.module('ROD', ['ui.bootstrap', 'ui.router', 'angular-loading-bar', 'ngAnimate', 'CREATE-RELEASE', 'EDIT-RELEASE', 'RELEASE-DASHBOARD', 'UPDATE-APPLICATIONS', 'UPDATE-MILESTONES']);
