(function (app) {
	app.config(['momentPickerProvider', function (momentPickerProvider) {
		momentPickerProvider.options({
			/* Picker properties */
			locale: 'en',
			format: 'ddd hh:mm A MM/DD/YY',
			minView: 'decade',
			maxView: 'minute',
			startView: 'year',
			autoclose: true,
			today: false,
			keyboard: true,

			/* Extra: Views properties */
			leftArrow: '&larr;',
			rightArrow: '&rarr;',
			yearsFormat: 'YYYY',
			monthsFormat: 'MMM',
			daysFormat: 'D',
			hoursFormat: 'hh A',
			minutesFormat: 'hh:mm',
			secondsFormat: 'ss',
			minutesStep: 5,
			secondsStep: 1
		});
	}]).config(['$httpProvider', function ($httpProvider) {
		//initialize get if not there
		if (!$httpProvider.defaults.headers.get) {
			$httpProvider.defaults.headers.get = {};
		}

		//disable IE ajax request caching
		$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
		// extra
		$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
		$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	}]).config(appConfig);

	function appConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('welcome', {
			url: "/",
			templateUrl: FILES.HOME,
			controller: 'SelectController',
			resolve: {
				engagements: getAllEngagements
			}
		});

		getAllEngagements.$inject = ['indexService'];

		function getAllEngagements(indexService) {
			return indexService.getAllEngagements();
		}
	}
})(angular.module('ROD'));
