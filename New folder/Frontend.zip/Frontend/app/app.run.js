(function (app) {

	app.run(Authenticate);

	Authenticate.$inject = ['USER', 'userService'];

	function Authenticate(USER, userService) {
		userService.getEngagementsByUser(USER.ATTID).then(function (response) {
			if (response.engagements) {
				if (response.engagements.length > 0) {
					USER.isReleaseAdmin.value = true;
					USER.isReleaseAdmin.ofEngagement = response.engagements[0].id;
				}
				console.log(USER);
			}
		}, function () {
			console.log("Failed to Authenticate");
		});
	}

})(angular.module('ROD'));
