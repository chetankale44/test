(function (app) {
	app.factory('modalFactory', modalFactory);

	modalFactory.$inject = ['$uibModal', 'FILES'];

	function modalFactory($uibModal, FILES) {

		var factory = {
			getModal: getModal,
			getPrompt: getPrompt,
			getDialog: getDialog
		};

		function getModal(template, controller, resolve) {
			return $uibModal.open({
				animation: true,
				ariaLabelledBy: 'modal-title',
				ariaDescribedBy: 'modal-body',
				templateUrl: template,
				size: "lg",
				controller: controller,
				resolve: {
					data: function () {
						return resolve;
					}
				}
			});
		}

		function getPrompt(deleting) {
			return $uibModal.open({
				ariaLabelledBy: 'modal-title',
				ariaDescribedBy: 'modal-body',
				controller: function ($scope) {
					$scope.deleting = deleting;
				},
				templateUrl: FILES.DELETE,
				size: 'sm'
			});
		}

		function getDialog() {
			return $uibModal.open({
				animation: true,
				ariaLabelledBy: 'modal-title',
				ariaDescribedBy: 'modal-body',
				templateUrl: FILES.RESET,
				size: 'sm'
			});
		}
		return factory;
	}
})(angular.module('ROD'));
