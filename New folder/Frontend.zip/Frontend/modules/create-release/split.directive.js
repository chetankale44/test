/*TODO Debounce directive*/
(function (app) {
	app.directive('splitDmanagers', function () {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function (scope, element, attr, ngModel) {
				function fromUser(text) {
					scope.milestone.deploymentManagers = [];
					var managers = scope.milestone.deploymentManagers;
					text.split(',').forEach(function (user, index) {
						managers.push({
							attid: user.trim()
						});
					});
					return managers;
				}

				function toUser(jsonArray) {
					if (jsonArray) {
						var splitUsers = [];
						jsonArray.forEach(function (user, index) {
							splitUsers.push(user.attid);
						});
						return splitUsers.join(',');
					}
				}
				ngModel.$parsers.push(fromUser);
				ngModel.$formatters.push(toUser);
			}
		};
	});
})(angular.module('CREATE-RELEASE'));

(function (app) {
	app.directive('splitAppAdmins', function () {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function (scope, element, attr, ngModel) {
				function fromUser(text) {
					scope.application.details[0].applicationAdmins = [];
					var managers = scope.application.details[0].applicationAdmins;
					text.split(',').forEach(function (user, index) {
						managers.push({
							attid: user.trim()
						});
					});
					return managers;
				}

				function toUser(jsonArray) {
					if (jsonArray) {
						var splitUsers = [];
						jsonArray.forEach(function (user, index) {
							splitUsers.push(user.attid);
						});
						return splitUsers.join(',');
					}
				}
				ngModel.$parsers.push(fromUser);
				ngModel.$formatters.push(toUser);
			}
		};
	});
})(angular.module('CREATE-RELEASE'));
