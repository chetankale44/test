(function (app) {
	app.controller('CreateRelease2Controller', CreateRelease2Controller);

	CreateRelease2Controller.$inject = ['$scope', 'releaseService', '$state', '$stateParams', 'CONSTANTS'];

	function CreateRelease2Controller($scope, releaseService, $state, $stateParams, CONSTANTS) {

		//Scope Variables
		$scope.release = {};
		$scope.selectedCategory = {};
		$scope.alphaNumeric = CONSTANTS.REGEX.NAME;
		$scope.adminRegex = CONSTANTS.REGEX.ADMIN;
		$scope.saving = false;

		//Scope Functions
		$scope.addCategoryDetails = addCategoryDetails;
		$scope.removeCategory = removeCategory;
		$scope.selectCategory = selectCategory;
		$scope.addApplication = addApplication;
		$scope.removeApplication = removeApplication;
		$scope.saveRelease = saveRelease;

		activate();

		function activate() {
			if ($stateParams.release) {
				$scope.release = $stateParams.release;
				$scope.release.categoryDetails = [];
				addCategoryDetails();
				selectCategory($scope.release.categoryDetails[0]);
			}
		}

		function saveRelease() {
			$scope.saving = true;
			console.log($scope.release);
			releaseService.saveRelease($scope.release).then(function (response) {
				alert('saved');
				releaseService.savedRelease = null;
				$state.go('welcome');
			});
		}

		function removeApplication(application) {
			var applications = $scope.selectedCategory.applications;
			if (applications.length > 1) {
				applications.splice(applications.indexOf(application), 1);
			}
		}

		function addApplication() {
			var applications = $scope.selectedCategory.applications;
			var order = 0;
			if (applications.length > 0) {
				order = (applications[applications.length - 1].details[0].order + 1);
			}
			applications.push({
				details: [{
					order: order,
					applicationAdmins: [{}]
				}]
			});
		}

		function selectCategory(categoryDetails) {
			$scope.selectedCategory = categoryDetails.category;
		}

		function removeCategory(categoryDetail) {
			var categoryDetails = $scope.release.categoryDetails;
			if (categoryDetails.length > 1) {
				categoryDetails.splice(categoryDetails.indexOf(categoryDetail), 1);
			}
		}

		function addCategoryDetails() {
			var categoryDetails = $scope.release.categoryDetails;
			var order = 0;
			if (categoryDetails && categoryDetails.length > 0)
				order = categoryDetails[categoryDetails.length - 1].order + 1;
			categoryDetails.splice(categoryDetails.length, 0, {
				order: order,
				category: {
					applications: [{
						details: [{
							order: 0,
							applicationAdmins: [{}]
						}]
					}]
				}
			});
		}
	}
})(angular.module('CREATE-RELEASE'));
