(function (app) {
	app.controller('CreateRelease1Controller', CreateRelease1Controller);

	CreateRelease1Controller.$inject = ['$scope', '$state', 'releaseService', 'user', 'indexService', 'CONSTANTS'];

	function CreateRelease1Controller($scope, $state, releaseService, user, indexService, CONSTANTS) {

		//Scope Variables
		$scope.errorMessage = false;
		$scope.engagements = user.engagements;
		$scope.engagement = {};
		$scope.release = {};
		$scope.alphaNumeric = CONSTANTS.REGEX.NAME;
		$scope.mileNameRegex = CONSTANTS.REGEX.NAME;
		$scope.current = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);
		$scope.release.defaultMilestones = Array.apply(null, Array(5)).map(function (value, index) {
			return {
				order: index
			};
		});

		//Scope Functions
		$scope.importRelease = importRelease;
		$scope.addMilestone = addMilestone;
		$scope.saveRelease = saveRelease;
		$scope.removeMilestone = removeMilestone;
		$scope.setEngagement = setEngagement;

		activate();

		function activate() {}

		function setEngagement() {
			indexService.getReleaseAdmins($scope.engagement.id).then(function (response) {
				$scope.release.engagement = $scope.engagement;
				$scope.release.engagement.releaseAdmins = response.releaseAdmins;
			});
		}

		function saveRelease() {
			console.log('$scope.release');
			$state.go('createCategories', {
				release: $scope.release
			});
		}

		function importRelease() {
			console.log($scope.releaseId);
			releaseService.getRelease($scope.releaseId).then(function (response) {
				response.id = "";
				response.name = "";
				response.start = "";
				response.end = "";
				$scope.release = response;
			});
		}

		function addMilestone() {
			var milestones = $scope.release.defaultMilestones;
			var order = milestones[milestones.length - 1].order + 1;
			if (milestones.length < CONSTANTS.MAX_PRIMARY_MILESTONES) {
				milestones.splice(milestones.length, 0, {
					order: order,
					primaryMilestone: {}
				});
				$scope.errorMessage = false;
			} else {
				$scope.errorMessage = "There should be maximum 8 milestones"
			}
		}

		function removeMilestone(milestone) {
			var milestones = $scope.release.defaultMilestones;
			if (milestones.length > CONSTANTS.MIN_PRIMARY_MILESTONES) {
				milestones.splice(milestones.indexOf(milestone), 1);
				$scope.errorMessage = false;
			} else {
				$scope.errorMessage = "There should be minimum 5 milestones";
			}
		}

	}
})(angular.module('CREATE-RELEASE'));
