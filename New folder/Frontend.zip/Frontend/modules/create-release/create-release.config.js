(function (app) {
	app.constant('CREATE-RELEASE.FILES', (function () {
		return {
			'CREATE_1': '../modules/create-release/create-release-1.html',
			'CREATE_2': '../modules/create-release/create-release-2.html'
		}
	})()).config(createReleaseConfig);

	createReleaseConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'CREATE-RELEASE.FILES']

	function createReleaseConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('createMilestones', {
			url: "/create-milestones",
			templateUrl: FILES.CREATE_1,
			controller: 'CreateRelease1Controller',
			resolve: {
				user: getEngagementsByUser
			}
		}).state('createCategories', {
			url: "/create-categories",
			templateUrl: FILES.CREATE_2,
			controller: 'CreateRelease2Controller',
			params: {
				release: null
			}
		});
	}

	getEngagementsByUser.$inject = ['userService', 'USER'];

	function getEngagementsByUser(userService, USER) {
		return userService.getEngagementsByUser(USER.ATTID);
	}

})(angular.module('CREATE-RELEASE'));
