angular.module('CREATE-RELEASE', ['ui.router', 'colorpicker.module', 'moment-picker']);
