(function (app) {
	app.controller('EditRelease1Controller', EditRelease1Controller);

	EditRelease1Controller.$inject = ['$scope', '$state', '$stateParams', 'releaseService', 'CONSTANTS'];

	function EditRelease1Controller($scope, $state, $stateParams, releaseService, CONSTANTS) {

		//Scope Variables
		$scope.errorMessage = false;
		$scope.release = {};
		$scope.saving = false;
		$scope.alphaNumeric = CONSTANTS.REGEX.NAME;
		$scope.mileNameRegex = CONSTANTS.REGEX.NAME;
		$scope.current = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);
		$scope.release.defaultMilestones = Array.apply(null, Array(5)).map(function (value, index) {
			return {
				order: index
			};
		});

		//Scope Functions
		$scope.addMilestone = addMilestone;
		$scope.saveRelease = saveRelease;
		$scope.removeMilestone = removeMilestone;

		activate();
		//		testRelease();

		function testRelease() {
			releaseService.getRelease(12).then(function (response) {
				$scope.release = response;
				console.log("Release edit");
			});
		}

		function activate() {
			if ($stateParams.release) {
				$scope.release = $stateParams.release;
				console.log("Release edit");
				console.log($scope.release);
			}
		}

		function saveRelease() {
			$scope.saving = true;
			releaseService.saveRelease($scope.release).then(function (response) {
				$scope.release = response;
				$state.go('releaseDashboard', {
					releaseId: $scope.release.id
				});
			});
		}

		function addMilestone() {
			var milestones = $scope.release.defaultMilestones;
			var order = milestones[milestones.length - 1].order + 1;
			if (milestones.length < CONSTANTS.MAX_PRIMARY_MILESTONES) {
				milestones.splice(milestones.length, 0, {
					order: order,
					primaryMilestone: {}
				});
				$scope.errorMessage = false;
			} else {
				$scope.errorMessage = "There should be maximum 8 milestones"
			}
		}

		function removeMilestone(milestone) {
			var milestones = $scope.release.defaultMilestones;
			if (milestones.length > CONSTANTS.MIN_PRIMARY_MILESTONES) {
				milestones.splice(milestones.indexOf(milestone), 1);
				$scope.errorMessage = false;
			} else {
				$scope.errorMessage = "There should be minimum 5 milestones";
			}
		}
	}
})(angular.module('EDIT-RELEASE'));
