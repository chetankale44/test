(function (app) {
	app.service('categoryService', ['$http', 'API', categoryService]);

	function categoryService($http, API) {
		var service = {
			deleteCategory: deleteCategory
		};

		return service;

		function deleteCategory(categoryDetail) {
			console.log('deleted: ' + categoryDetail);
			//http://localhost:8080/RMD/services/categories/delete
			return $http({
				method: 'DELETE',
				url: API.CATEGORIES_DELETE,
				data: categoryDetail,
				headers: {
					'Content-type': 'application/json;charset=utf-8'
				}
			}).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}
	}
})(angular.module('EDIT-RELEASE'));
