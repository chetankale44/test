(function (app) {
	app.constant('EDIT-RELEASE.FILES', (function () {
		return {
			'EDIT_1': '../modules/edit-release/edit-release-1.html',
			'EDIT_2': '../modules/edit-release/edit-release-2.html'
		}
	})()).config(editReleaseConfig);

	editReleaseConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'EDIT-RELEASE.FILES'];

	function editReleaseConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('editRelease', {
			url: "/edit-release",
			templateUrl: FILES.EDIT_1,
			controller: 'EditRelease1Controller',
			params: {
				release: null
			}
		}).state('editCategories', {
			url: "/edit-categories",
			templateUrl: FILES.EDIT_2,
			controller: 'EditRelease2Controller',
			params: {
				release: null
			}
		});
	}
})(angular.module('EDIT-RELEASE'));
