angular.module('EDIT-RELEASE', ['ui.router', 'colorpicker.module', 'moment-picker']);
