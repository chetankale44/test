(function (app) {
	app.controller('EditRelease2Controller', EditRelease2Controller);

	EditRelease2Controller.$inject = ['$scope', 'releaseService', '$state', '$stateParams', '$http', 'modalFactory', 'categoryService', 'applicationService', 'EDIT-RELEASE.FILES', 'CONSTANTS'];

	function EditRelease2Controller($scope, releaseService, $state, $stateParams, $http, modalFactory, categoryService, applicationService, FILES, CONSTANTS) {

		//Scope Variables
		$scope.release = {};
		$scope.selectedCategory = {};
		$scope.alphaNumeric = CONSTANTS.REGEX.NAME;
		$scope.adminRegex = CONSTANTS.REGEX.ADMIN;
		$scope.saving = false;

		//Scope Functions
		$scope.addCategoryDetails = addCategoryDetails;
		$scope.removeCategory = removeCategory;
		$scope.selectCategory = selectCategory;
		$scope.addApplication = addApplication;
		$scope.removeApplication = removeApplication;
		$scope.saveRelease = saveRelease;


		activate();

		//		testRelease();

		function testRelease() {
			releaseService.getRelease(12).then(function (response) {
				$scope.release = response;
				$scope.release.categoryDetails = sortByOrder($scope.release.categoryDetails);
				selectCategory($scope.release.categoryDetails[0]);
			});
		}


		function activate() {
			if ($stateParams.release) {
				$scope.release = $stateParams.release;
				$scope.release.categoryDetails = sortByOrder($scope.release.categoryDetails);
				selectCategory($scope.release.categoryDetails[0]);
			}
		}

		/*Utility*/
		function sortByOrder(array) {
			return array.sort(function (a, b) {
				var x = a.order;
				var y = b.order;
				return ((x < y) ? -1 : ((x > y) ? 1 : 0));
			});
		}

		function saveRelease() {
			$scope.saving = true;
			releaseService.saveRelease($scope.release).then(function (response) {

				$scope.release = response;
				$state.go('releaseDashboard', {
					releaseId: $scope.release.id
				});
			});
		}

		function removeApplication(application) {

			modalFactory.getPrompt("Application").result.then(function (response) {
				var applications = $scope.selectedCategory.applications;
				if (applications.length > 1) {
					$scope.saving = true;

					applicationService.deleteApplication(application).then(function (response) {
						$scope.saving = false;
						applications.splice(applications.indexOf(application), 1);
					});
				}
			}, function (response) {
				console.log('Modal dismissed');
			});
		}

		function addApplication() {
			var applications = $scope.selectedCategory.applications;
			var order = 0;
			if (applications.length > 0) {
				order = (applications[applications.length - 1].details[0].order + 1);
			}
			applications.push({
				details: [{
					order: order,
					applicationAdmins: [{}]
				}]
			});
		}

		function selectCategory(categoryDetail) {
			$scope.selectedCategory = categoryDetail.category;
		}

		function removeCategory(categoryDetail) {

			modalFactory.getPrompt("Category").result.then(function (response) {

				var categoryDetails = $scope.release.categoryDetails;
				if (categoryDetails.length > 1) {
					$scope.saving = true;

					categoryService.deleteCategory(categoryDetail).then(function (response) {
						$scope.saving = false;
						categoryDetails.splice(categoryDetails.indexOf(categoryDetail), 1);
					});
				}

			}, function (response) {
				console.log('Modal dismissed');
			});
		}

		function addCategoryDetails() {
			var categoryDetails = $scope.release.categoryDetails;
			var order = 0;
			if (categoryDetails && categoryDetails.length > 0)
				order = categoryDetails[categoryDetails.length - 1].order + 1;
			categoryDetails.splice(categoryDetails.length, 0, {
				order: order,
				category: {
					applications: [{
						details: [{
							order: 0,
							applicationAdmins: [{}]
						}]
					}]
				}
			});
		}
	}
})(angular.module('EDIT-RELEASE'));
