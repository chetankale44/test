(function (app) {
	app.controller('UpdateMilestonesController', UpdateMilestonesController);

	UpdateMilestonesController.$inject = ['$scope', '$state', '$stateParams', 'applicationService', 'modalFactory', 'releaseService', 'USER', 'FILES'];

	function UpdateMilestonesController($scope, $state, $stateParams, applicationService, modalFactory, releaseService, USER, FILES) {

		//Scope Variables
		$scope.selected = false;
		$scope.release = {};

		//Scope Functions
		$scope.selectApplication = selectApplication;
		$scope.resetModified = resetModified;
		$scope.setActual = setActual;
		$scope.resetActual = resetActual;
		$scope.updateStatus = updateStatus;
		$scope.isCategoryAdmin = isCategoryAdmin;
		$scope.isAppAdmin = isAppAdmin;
		$scope.isDepManager = isDepManager;

		//		testRelease();
		activate();

		function activate() {
			$scope.release = $stateParams.release;
		}

		function testRelease() {
			releaseService.getRelease(12).then(function (response) {
				$scope.release = response;
				$scope.application = $scope.release.categoryDetails[0].category.applications[0];
				assignRoles($scope.release);
			});
		}


		function isCategoryAdmin(categoryDetails) {
			if (USER.isReleaseAdmin.ofSelectedEngagement) {
				return true;
			} else {
				return categoryDetails.category.applications.reduce(function (result, application) {
					return result || isAppAdmin(application);
				}, false);
			}
		}

		function isAppAdmin(application) {
			if (USER.isReleaseAdmin.ofSelectedEngagement) {
				return true;
			} else if (USER.isAppAdmin.value) {
				if (USER.isAppAdmin.ofApplications.indexOf(application.id) != -1) {
					return true;
				} else if (USER.isDeploymentManager.value) {
					return (USER.isDeploymentManager.ofApplications.indexOf(application.id) != -1);
				} else {
					return false;
				}
			} else {
				return application.milestoneStatus.reduce(function (result, milestone) {
					return result || isDepManager(milestone);
				}, false);
			}
		}

		function isDepManager(milestone) {
			if (USER.isReleaseAdmin.ofSelectedEngagement) {
				return true;
			} else if (USER.isDeploymentManager.value) {
				return (USER.isDeploymentManager.ofMilestones.indexOf(milestone.id) != -1);
			}
			return false;
		}

		function resetActual(milestone) {
			var modalInstance = modalFactory.getDialog();

			modalInstance.result.then(function () {
				milestone.actual = "";
			}, function () {
				console.log('dismissed');
			});
		}

		function updateStatus() {
			applicationService.updateApplication($scope.application).then(function (response) {
				$scope.application = response;
                onRouteChangeOff();
				alert("Saved");
			});
		}

		function setActual(milestone) {
			var currentTime = moment.utc();
			milestone.actual = moment.utc().tz('America/Chicago').format("ddd hh:mm A MM/DD/YY");
		}

		function resetModified(milestone) {
			var modalInstance = modalFactory.getDialog();

			modalInstance.result.then(function () {
				milestone.modified = "";
			}, function () {
				console.log('dismissed');
			});
		}

		function selectApplication(application) {
			$scope.selected = true;
			$scope.application = application;
		}
	}
})(angular.module('ROD'));
