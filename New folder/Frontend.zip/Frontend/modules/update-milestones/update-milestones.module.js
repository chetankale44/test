angular.module('UPDATE-MILESTONES', ['ui.router', 'moment-picker']);
