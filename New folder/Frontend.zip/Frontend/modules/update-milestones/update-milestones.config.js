(function (app) {
	app.constant('UPDATE-MILESTONES.FILES', (function () {
		var prefix = '../modules/update-milestones/';
		return {
			'UPDATE_STATUS': prefix + 'update-milestones.html'
		}
	})()).config(updateApplicationsConfig);

	updateApplicationsConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'UPDATE-MILESTONES.FILES'];

	function updateApplicationsConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('updateStatus', {
			url: "/update-status",
			templateUrl: FILES.UPDATE_STATUS,
			controller: 'UpdateMilestonesController',
			params: {
				release: null
			}
		});
	}

})(angular.module('UPDATE-MILESTONES'));
