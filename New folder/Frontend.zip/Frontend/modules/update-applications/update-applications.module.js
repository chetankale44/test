angular.module('UPDATE-APPLICATIONS', ['ui.router', 'moment-picker']);
