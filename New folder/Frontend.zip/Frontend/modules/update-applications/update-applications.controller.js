(function (app) {
	app.controller('UpdateApplicationsController', UpdateApplicationsController);

	UpdateApplicationsController.$inject = ['$scope', '$state', '$stateParams', 'applicationService', 'releaseService', 'USER', 'CONSTANTS'];

	function UpdateApplicationsController($scope, $state, $stateParams, applicationService, releaseService, USER, CONSTANTS) {

		//Scope Variables
		$scope.user = USER;
		$scope.selected = false;
		$scope.adminRegex = CONSTANTS.REGEX.ADMIN;
		$scope.release = {};

		//Scope Functions
		$scope.selectApplication = selectApplication;
		$scope.saveMilestone = saveMilestone;
		$scope.isDisabled = isDisabled;
		$scope.isCategoryAdmin = isCategoryAdmin;
		$scope.isAppAdmin = isAppAdmin;

		//		testRelease();
		activate();

		function activate() {
			$scope.release = $stateParams.release;
		}

		function testRelease() {
			releaseService.getRelease(12).then(function (response) {
				console.log(response);
				$scope.release = response;
			});
		}

		function isCategoryAdmin(categoryDetails) {
			if (USER.isReleaseAdmin.ofSelectedEngagement) {
				return true;
			} else {
				return categoryDetails.category.applications.reduce(function (result, application) {
					return result || isAppAdmin(application);
				}, false);
			}
		}

		function isAppAdmin(application) {
			if (USER.isReleaseAdmin.ofSelectedEngagement) {
				return true;
			} else if (USER.isAppAdmin.ofApplications.indexOf(application.id) != -1) {
				return true;
			} else {
				return false;
			}
		}

		function isDisabled(milestone) {
			var disabled = false;
			$scope.release.defaultMilestones.forEach(function (defaultMilestone, index) {
				if (defaultMilestone.order == milestone.order) {
					disabled = defaultMilestone.mandatory;
					return;
				}
			});
			return disabled;
		}

		function saveMilestone() {
			applicationService.updateApplication($scope.application).then(function (data) {
				alert('data has been updated');
				$scope.application = data;
			});
		}

		function selectApplication(application) {
			$scope.selected = true;
			$scope.application = application;
		}
	}
})(angular.module('UPDATE-APPLICATIONS'));
