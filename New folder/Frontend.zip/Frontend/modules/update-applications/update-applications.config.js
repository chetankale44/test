(function (app) {
	app.constant('UPDATE-APPLICATIONS.FILES', (function () {
		var prefix = '../modules/update-applications/';
		return {
			'APP_ADMIN': prefix + 'update-applications.html'
		}
	})()).config(updateApplicationsConfig);

	updateApplicationsConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'UPDATE-APPLICATIONS.FILES'];

	function updateApplicationsConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('appAdmin', {
			url: "/application-admin",
			templateUrl: FILES.APP_ADMIN,
			controller: 'UpdateApplicationsController',
			params: {
				release: null
			}
		});
	}
})(angular.module('UPDATE-APPLICATIONS'));
