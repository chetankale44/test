(function (app) {
	app.service('applicationService', ['$http', 'API', applicationService]);

	function applicationService($http, API) {
		var service = {
			updateApplication: updateApplication,
			deleteApplication: deleteApplication
		};

		return service;

		function updateApplication(application) {
			console.log(application);
			//http://localhost:8080/RMD/services/applications/issues/add
			return $http.post(API.APPLICATION_UPDATE, application).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}

		function deleteApplication(application) {
			console.log('deleted: ' + application);

			return $http({
				method: 'DELETE',
				url: API.APPLICATION_DELETE,
				data: application,
				headers: {
					'Content-type': 'application/json;charset=utf-8'
				}
			}).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}
	}
})(angular.module('UPDATE-APPLICATIONS'));
