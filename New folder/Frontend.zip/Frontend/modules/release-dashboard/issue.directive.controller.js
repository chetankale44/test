(function (app) {

	app.controller('IssueDirectiveController', IssueDirectiveController);

	IssueDirectiveController.$inject = ['$scope', 'modalFactory', 'RELEASE-DASHBOARD.FILES'];

	function IssueDirectiveController($scope, modalFactory, FILES) {

		//Scope Variables
		$scope.application = $scope.data;
		$scope.open = 0;
		$scope.close = 0;

		//Scope Functions
		$scope.viewIssues = viewIssues;

		activate();

		function activate() {
			var open = 0,
				close = 0;
			for (let issue of $scope.application.details[0].issues) {
				if (issue.active)
					open++;
				else
					close++;
			}
			$scope.open = open;
			$scope.close = close;
		}

		function viewIssues() {
			var viewModalInstance = modalFactory.getModal(FILES.ISSUE_VIEW, ViewIssueController, {
				application: $scope.application
			});

			viewModalInstance.result.then(function (application) {
				$scope.application = application;
			}, function () {
				$scope.refresh();
			});

			ViewIssueController.$inject = ['$scope', 'data', 'USER'];

			function ViewIssueController($scope, data, USER) {

				//Scope Variables
				$scope.application = data.application;

				//Scope Functions
				$scope.addIssue = addIssue;
				$scope.editIssue = editIssue;
				$scope.isAppAdmin = isAppAdmin;

				function isAppAdmin() {
					return (USER.isReleaseAdmin.ofSelectedEngagement || USER.isDeploymentManager.ofApplications.indexOf($scope.application.id) != -1)
				}

				function addIssue() {
					var addModalInstance = modalFactory.getModal(FILES.ISSUE_ADD, AddIssueController, {
						application: $scope.application
					});

					addModalInstance.result.then(function (application) {
						$scope.application = application;
					}, function () {
						console.log('closed add');
					});

					AddIssueController.$inject = ['$scope', 'data', 'applicationService', 'USER', 'CONSTANTS'];

					function AddIssueController($scope, data, applicationService, USER, CONSTANTS) {

						//Scope Variables
						$scope.application = data.application;
						$scope.issue = {};

						//Scope Functions
						$scope.addIssue = addIssue;

						function addIssue() {
							var currentTime = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);
							var issue = $scope.issue;
							if (issue.active) {
								issue.open = currentTime;
							} else {
								issue.close = currentTime;
							}
							issue.updatedBy = USER.ATTID;
							$scope.application.details[0].issues.push(issue);
							applicationService.updateApplication($scope.application).then(function (response) {
								$scope.application = response;
								$scope.$close(response);
							});
						}
					}
				}

				function editIssue(index) {
					if (isAppAdmin()) {
						var editModalInstance = modalFactory.getModal(FILES.ISSUE_EDIT, EditIssueController, {
							application: $scope.application,
							issueIndex: index
						});
						editModalInstance.result.then(function (application) {
							$scope.application = application;
						}, function () {
							console.log('closed edit');
						});
					}

					EditIssueController.$inject = ['$scope', 'data', 'applicationService', 'CONSTANTS'];

					function EditIssueController($scope, data, applicationService, CONSTANTS) {

						//Scope Variables
						$scope.application = data.application;
						$scope.issue = $scope.application.details[0].issues[data.issueIndex];

						//Scope Functions
						$scope.saveIssue = saveIssue;

						function saveIssue() {
							var currentTime = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);
							var issue = $scope.issue;
							if (!issue.active) {
								issue.close = currentTime;
							}
							applicationService.updateApplication($scope.application).then(function (response) {
								$scope.application = response;
								$scope.$close(response);
							});
						}
					}
				}
			}
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
