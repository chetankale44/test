(function (app) {
	app.directive('gridHeight', gridHeight);

	gridHeight.$inject = ['$window'];

	function gridHeight($window) {
		return {
			link: function (scope, element, attrs) {
				element.css('height', Math.abs(190 - $window.innerHeight) + 'px');
			}
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
