(function (app) {
	app.directive('issues', issuesDirective);

	issuesDirective.$inject = ['RELEASE-DASHBOARD.FILES'];

	function issuesDirective(FILES) {
		return {
			scope: {
				data: "=data",
				refresh: "&refresh"
			},
			templateUrl: FILES.ISSUE_DIRECTIVE,
			controller: 'IssueDirectiveController'
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
