(function (app) {
	app.constant('RELEASE-DASHBOARD.FILES', (function () {
		var prefix = '../modules/release-dashboard/';
		return {
			'DASHBOARD': prefix + 'release-dashboard.html',
			'ISSUE_DIRECTIVE': prefix + 'issue.directive.html',
			'MILESTONE_DIRECTIVE': prefix + 'milestone.directive.html',
			'ISSUE_VIEW': prefix + 'issue-popup.html',
			'ISSUE_ADD': prefix + 'issue-add.html',
			'ISSUE_EDIT': prefix + 'issue-edit.html'
		}
	})()).config(releaseDashboardConfig);

	releaseDashboardConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'RELEASE-DASHBOARD.FILES'];

	function releaseDashboardConfig($stateProvider, $urlRouterProvider, FILES) {

		$urlRouterProvider.otherwise("/");

		$stateProvider.state('releaseDashboard', {
			url: "/release-dashboard/:releaseId",
			templateUrl: FILES.DASHBOARD,
			controller: 'ReleaseDashboardController',
			resolve: {
				release: getRelease
			},
			params: {
				releaseId: null
			}
		});
	}

	getRelease.$inject = ['releaseService', '$stateParams'];

	function getRelease(releaseService, $stateParams) {
		if ($stateParams.releaseId)
			return releaseService.getRelease($stateParams.releaseId);
		else
			return releaseService.viewRelease;
	}

})(angular.module('RELEASE-DASHBOARD'));
