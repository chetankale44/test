(function (app) {
	app.directive('roleIcon', roleIcon);

	roleIcon.$inject = ['USER'];

	function roleIcon(USER) {
		return {
			link: function (scope, element, attrs) {
				if (USER.isReleaseAdmin.ofSelectedEngagement) {
					element.addClass("glyphicon-king");
				} else if (USER.isAppAdmin.value) {
					element.addClass("glyphicon-tower");
				} else if (USER.isDeploymentManager.value) {
					element.addClass("glyphicon-knight");
				} else {
					element.addClass("glyphicon-pawn");
				}

			}
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
