(function (app) {
	app.directive('milestone', milestoneDirective);

	milestoneDirective.$inject = ['RELEASE-DASHBOARD.FILES'];

	function milestoneDirective(FILES) {
		return {
			scope: {
				data: "=data"
			},
			templateUrl: FILES.MILESTONE_DIRECTIVE,
			controller: 'MilestoneDirectiveController',
			replace: true
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
