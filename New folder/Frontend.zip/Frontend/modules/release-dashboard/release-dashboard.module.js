angular.module('RELEASE-DASHBOARD', ['agGrid', 'ui.router']);
