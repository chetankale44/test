(function (app) {

	app.controller('MilestoneDirectiveController', MilestoneDirectiveController);

	MilestoneDirectiveController.$inject = ['$scope', '$sce', 'RELEASE-DASHBOARD.FILES'];

	function MilestoneDirectiveController($scope, $sce, FILES) {

		var milestone = $scope.data;

		//Scope Variables
		$scope.color = milestone.color;
		$scope.popover = null;
		$scope.time = null;
		$scope.date = null;

		if (milestone.applicable) {

			$scope.popover = $sce.trustAsHtml('<table class="table table-bordered table-striped table-hover"><tr><td>Planned</td><td>' + milestone.planned.toUpperCase() + '</td></tr><tr><td>Updated ETC</td><td>' + (milestone.modified == null ? "--" : milestone.modified.toUpperCase()) + '</td></tr><tr><td>Completed</td><td>' + (milestone.completed == null ? "--" : milestone.completed.toUpperCase()) + '</td></tr></table>');

			var status;
			if (milestone.completed) {
				status = milestone.completed.toUpperCase();
			} else if (milestone.modified) {
				status = milestone.modified.toUpperCase();
			} else {
				status = milestone.planned.toUpperCase();
			}

			$scope.time = milestone.modified ? status.substr(0, 12) + '*' : status.substr(0, 12);
			$scope.date = status.substr(13, status.length);

		} else {
			$scope.popover = $sce.trustAsHtml('<table class="table table-bordered table-striped table-hover"><tr><td>Planned</td><td>--</td></tr><tr><td>Updated ETC</td><td>--</td></tr><tr><td>Completed</td><td>--</td></tr></table>');
			$scope.time = 'N/A';
		}

	}
})(angular.module('RELEASE-DASHBOARD'));
