(function (app) {

	agGrid.initialiseAgGridWithAngular1(angular);

	app.controller('ReleaseDashboardController', ReleaseDashboardController);

	ReleaseDashboardController.$inject = ['$scope', '$interval', '$state', '$sce', '$stateParams', 'releaseService', 'release', 'USER', 'CONSTANTS'];

	function ReleaseDashboardController($scope, $interval, $state, $sce, $stateParams, releaseService, release, USER, CONSTANTS) {
		console.log(release);

		//Scope Variables
		$scope.release = {};
		$scope.applicationCount = 0;
		$scope.lastRefreshed = 0;

		//Scope Functions
		$scope.refreshDashboard = refreshDashboard;
		$scope.clearFilters = clearFilters;
		$scope.exportData = exportData;
		$scope.clearFilters = clearFilters;

		var autoRefresh;

		activate();

		function activate() {
			if (!release) {
				$state.go('welcome');
			}
			$scope.release = release;
			USER.isReleaseAdmin.ofSelectedEngagement = isReleaseAdmin($scope.release);
			assignRoles($scope.release);
			initGrid($scope.release);
			autoRefresh = startAutoRefresh();
		}

		function startAutoRefresh() {
			return $interval(refreshDashboard, CONSTANTS.REFRESH_INTERVAL);
		}

		function stopAutoRefresh() {
			$interval.cancel(autoRefresh);
		}

		$scope.$on('$destroy', function () {
			stopAutoRefresh();
		});

		function isReleaseAdmin(release) {
			return (USER.isReleaseAdmin.ofEngagement == release.engagement.id);
		}

		function assignRoles(release) {
			if (!USER.isReleaseAdmin.ofSelectedEngagement) {
				var user = USER.ATTID.toUpperCase();
				var appAdmins = {};
				var depManagers = {};
				var depManagersApps = {};
				release.categoryDetails.forEach(function (categoryDetail, index) {

					categoryDetail.category.applications.forEach(function (application, index) {

						application.details[0].applicationAdmins.forEach(function (appAdmin, index) {

							var admin = appAdmin.attid.toUpperCase();

							if (!appAdmins[admin]) appAdmins[admin] = [];
							appAdmins[admin].push(application.id);

							if (!depManagersApps[admin]) depManagersApps[admin] = [];
							depManagersApps[admin].push(application.id);

							application.milestoneStatus.forEach(function (milestone, index) {
								if (!depManagers[admin]) depManagers[admin] = [];
								depManagers[admin].push(milestone.id);
							});

							application.milestoneStatus.forEach(function (milestone, index) {

								var pushOnce = true;
								milestone.deploymentManagers.forEach(function (depManager, index) {

									var manager = depManager.attid.toUpperCase();

									if (!depManagers[manager]) depManagers[manager] = [];
									depManagers[manager].push(milestone.id);
									if (!depManagersApps[manager]) depManagersApps[manager] = [];
									if (pushOnce) {
										depManagersApps[manager].push(application.id);
										pushOnce = false;
									}
								});

							});
						});

					});
				});
				USER.isAppAdmin.value = appAdmins.hasOwnProperty(user);
				if (USER.isAppAdmin.value) USER.isAppAdmin.ofApplications = appAdmins[user];

				USER.isDeploymentManager.value = depManagers.hasOwnProperty(user);
				if (USER.isDeploymentManager.value) {
					USER.isDeploymentManager.ofMilestones = depManagers[user];
					USER.isDeploymentManager.ofApplications = depManagersApps[user];
				}
				console.log(USER);
			}
		}

		/*Utility*/
		function sortByOrder(array) {
			return array.sort(function (a, b) {
				var x = a.order;
				var y = b.order;
				return ((x < y) ? -1 : ((x > y) ? 1 : 0));
			});
		}

		/*Utility*/
		function sortApplicationsByOrder(array) {
			return array.sort(function (a, b) {
				var x = a.details[0].order;
				var y = b.details[0].order;
				return ((x < y) ? -1 : ((x > y) ? 1 : 0));
			});
		}

		/**
		 * [[Create row data from data fetched from DB]]
		 * @author rx228x
		 * @param   {object}   release [[JSON fetched from DB]]
		 * @returns {Array} [[RowData to fill Grid]]
		 */
		function createRowData(release) {

			var rowData = [];

			release.categoryDetails = sortByOrder(release.categoryDetails);

			for (let categoryDetails of release.categoryDetails) {

				categoryDetails.category.applications = sortApplicationsByOrder(categoryDetails.category.applications);

				for (let application of categoryDetails.category.applications) {

					var row = {};

					row.categories = {
						name: categoryDetails.category.name,
						color: categoryDetails.color
					};

					row.applications = application.name;

					for (let milestone of application.milestoneStatus) {
						var status = getStatus(milestone);
						row[milestone.primaryMilestone.name] = {
							planned: milestone.planned,
							completed: milestone.actual,
							modified: milestone.modified,
							status: status.name,
							color: status.color,
							applicable: milestone.applicable,
							id: milestone.id
						};
					}
					row.details = application;
					rowData.push(row);
				}
			}
			return rowData;

		}

		//TODO Status Service
		function getStatus(milestone) {

			var notComplete = {
				color: CONSTANTS.STATUS_NOT_COMPLETE,
				name: "Not Complete"
			};
			var complete = {
				color: CONSTANTS.STATUS_COMPLETE,
				name: "Complete"
			};
			var atRisk = {
				color: CONSTANTS.STATUS_AT_RISK,
				name: "At Risk"
			};
			var missedDeadline = {
				color: CONSTANTS.STATUS_MISSED_DEADLINE,
				name: "Missed Deadline"
			};
			var notApplicable = {
				color: CONSTANTS.STATUS_NOT_APPLICABLE,
				name: "NA"
			};

			/*TODO Add to Angular Constants*/
			var currentTime = moment.utc();
			var planned = moment.utc(milestone.planned + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
			var atRiskDeadline = moment.utc(milestone.planned + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z).subtract(CONSTANTS.AT_RISK_DEADLINE, 'minutes');
			var modified = moment.utc(milestone.modified + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
			var actual = moment.utc(milestone.actual + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);

			if (!milestone.applicable)
				return notApplicable;

			if (milestone.actual)
				return complete;

			if (!milestone.modified) {
				if (atRiskDeadline.isBefore(currentTime) && (currentTime.isBefore(planned) || currentTime.isBefore(modified))) return atRisk;
				else if (currentTime.isBefore(planned)) return notComplete;
				else if (planned.isBefore(currentTime)) return missedDeadline;
			} else {
				if (currentTime.isBefore(modified)) return atRisk;
				else if (modified.isBefore(currentTime)) return missedDeadline;
			}
		}

		function createColumnDefs(release) {

			var milestones = [];

			release.defaultMilestones = sortByOrder(release.defaultMilestones);

			for (let milestone of release.defaultMilestones) {
				milestones.push({
					headerName: milestone.primaryMilestone.name,
					field: milestone.primaryMilestone.name,
					headerTooltip: milestone.primaryMilestone.desc,
					width: 150,
					cellClass: 'cell-custom',
					filter: 'set',
					filterParams: {
						newRowsAction: 'keep'
					},
					comparator: dateComparator,
					cellRenderer: milestoneCellRenderer,
					keyCreator: milestoneKeyCreator
				});
			}

			var columnDefs = [
				{
					headerName: 'Categories',
					field: 'categories',
					width: 150,
					suppressSizeToFit: true,
					pinned: 'left',
					filter: 'set',
					cellClass: 'cell-custom',
					filterParams: {
						comparator: function (a, b) {
							return a.localeCompare(b);
						},
						newRowsAction: 'keep'
					},
					cellRenderer: categoryCellRenderer,
					cellStyle: categoryCellStyler,
					keyCreator: categoryKeyCreator,
					comparator: categoryComparator
						},
				{
					headerName: 'Applications',
					field: 'applications',
					width: 125,
					suppressSizeToFit: true,
					pinned: 'left',
					cellClass: 'cell-custom',
					filter: 'set',
					filterParams: {
						newRowsAction: 'keep'
					}
						},
				{
					headerName: 'Milestones',
					children: milestones
						},
				{
					headerName: 'Issues',
					field: 'details',
					cellClass: 'cell-custom',
					width: 150,
					pinned: 'right',
					cellRenderer: issueCellRenderer,
					suppressMenu: true,
					suppressSorting: true
				}
						];

			return columnDefs;
		}

		function refreshDashboard() {
			console.log("refreshed");
			releaseService.getRelease($scope.release.id).then(function (response) {

				$scope.release = response;
				assignRoles($scope.release);
				$scope.lastRefreshed = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);
				var rowData = createRowData($scope.release);
				$scope.applicationCount = rowData.length;
				$scope.gridOptions.api.setRowData(rowData);
				$scope.gridOptions.api.refreshView();
				//				$scope.gridOptions.api.sizeColumnsToFit();
			});
		}


		function issueCellRenderer(params) {
			return '<issues data=\'' + JSON.stringify(params.value) + '\' refresh="refreshDashboard()"></milestone>';
		}


		/**
		 * [[Custom comparator for sorting dates]]
		 * @author rx228x
		 * @param   {object} milestone1 [[JSON object for milstone]]
		 * @param   {object} milestone2 [[JSON object for milstone]]
		 * @returns {number} [[positive, 0, negative number]]
		 */
		function dateComparator(milestone1, milestone2) {

			var date1 = null,
				date2 = null;

			if (!milestone1.applicable && !milestone2.applicable) return 0;
			else if (!milestone1.applicable) return 1;
			else if (!milestone2.applicable) return -1;

			if (milestone1.applicable && milestone2.applicable) {
				if (milestone1.completed) date1 = moment.utc(milestone1.completed + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
				else if (milestone1.modified) date1 = moment.utc(milestone1.modified + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
				else date1 = moment.utc(milestone1.planned + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);

				if (milestone2.completed) date2 = moment.utc(milestone2.completed + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
				else if (milestone2.modified) date2 = moment.utc(milestone2.modified + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);
				else date2 = moment.utc(milestone2.planned + CONSTANTS.TZ_OFFSET, CONSTANTS.TIME_FORMAT_Z);

				if (date1.isBefore(date2)) return 1;
				else if (date2.isBefore(date1)) return -1;
				else return 0
			}
		}

		/**
		 * [[Renderer for Milestone cells]]
		 * @author rx228x
		 * @param   {object} params [[cell data]]
		 * @returns {string} [[HTML string to render]]
		 */
		function milestoneCellRenderer(params) {
			return '<milestone data=\'' + JSON.stringify(params.value) + '\'></milestone>';
		}

		function milestoneKeyCreator(params) {
			return '<div class="btn status-key" style="background-color:' + params.value.color + ';"></div>  ' + params.value.status;
		}

		/**
		 * [[Renderer for Category cells]]
		 * @author rx228x
		 * @param   {object}   params [[JSON containing cell values]]
		 * @returns {string} [[name of category]]
		 */
		function categoryCellRenderer(params) {
			return params.value.name;
		}

		/**
		 * [[CSS property setter for Category cell]]
		 * @author rx228x
		 * @param   {object} params [[JSON containing cell values]]
		 * @returns {object} [[JSON containing color of category]]
		 */
		function categoryCellStyler(params) {
			return {
				backgroundColor: params.value.color
			};
		}

		/**
		 * [[Custom comparator for sorting categories]]
		 * @author rx228x
		 * @param   {object}   category1 [[JSON object for category]]
		 * @param   {object}   category2 [[JSON object for category]]
		 * @returns {number} [[positive, 0, negative number]]
		 */
		function categoryComparator(category1, category2) {
			return category1.name.localeCompare(category2.name);
		}

		/**
		 * [[Filter data for category column]]
		 * @author rx228x
		 * @param   {object}   params [[cell data]]
		 * @returns {Array} [[Name of categories to filter]]
		 */
		function categoryKeyCreator(params) {
			return params.value.name;
		}

		/**
		 * [[agGrid Plugin for exporting to Excel]]
		 * @author rx228x
		 */
		function exportData() {

			var params = {

				skipHeader: false,

				skipFooters: true,

				skipGroups: false,

				skipFloatingTop: true,

				skipFloatingBottom: true,

				allColumns: false,

				onlySelected: false,

				suppressQuotes: true,

				fileName: "ReleaseData.csv",

				columnSeparator: ","

			};

			params.processCellCallback = function (params) {
				console.log(params);
				switch (params.column.colId) {
					case 'categories':
						return params.value.name;
					case 'applications':
						return params.value;
					default:
						return params.value.planned + '|' + params.value.modified + '|' + params.value.completed;
				}
			};

			$scope.gridOptions.api.exportDataAsCsv(params);

		}

		/**
		 * [[Clear all filters on the grid]]
		 * @author rx228x
		 */
		function clearFilters() {

			$scope.gridOptions.api.setFilterModel(null);

			$scope.gridOptions.api.onFilterChanged();

		}

		function initGrid(release) {

			var rowData = createRowData(release);

			$scope.applicationCount = rowData.length;

			$scope.lastRefreshed = moment.utc().tz(CONSTANTS.TZ).format(CONSTANTS.TIME_FORMAT);

			$scope.gridOptions = {

				enableColResize: true,

				enableSorting: true,

				enableFilter: true,

				groupHeaders: true,

				rowHeight: 40,

				animateRows: true,

				suppressMenuMainPanel: true,

				suppressMovableColumns: true,

				suppressContextMenu: true,

				angularCompileRows: true,

				columnDefs: createColumnDefs(release),

				rowData: rowData
			};
		}

	}

})(angular.module('RELEASE-DASHBOARD'));
