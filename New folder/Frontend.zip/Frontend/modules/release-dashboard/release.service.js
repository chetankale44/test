(function (app) {
	app.service('releaseService', ['$http', 'API', releaseService]);

	function releaseService($http, API) {
		var service = {
			getRelease: getRelease,
			saveRelease: saveRelease,
			savedRelease: null,
			viewRelease: null
		};

		return service;

		//TODO Change to POST
		function saveRelease(release) {
			console.log("Saved Release");
			//../data/erList.json
			//http://localhost:8080/RMD/services/releases/save
			return $http.post(API.RELEASE_SAVE, release).then(function Success(response) {
				return response.data;
			}, function Error(error) {
				console.log(error);
			});
		}

		function getRelease(id) {
			//http://localhost:8080/RMD/services/releases/
			//../data/release-' + id + '.json
			//			/../data/release-5002.json
			return $http.get(API.RELEASE_GET).then(function Success(response) {
					console.log(response);
					service.viewRelease = {};
					service.viewRelease = response.data;
					return service.viewRelease;
				},
				function Error(error) {
					console.log(error);
				});
		}
	}
})(angular.module('RELEASE-DASHBOARD'));
